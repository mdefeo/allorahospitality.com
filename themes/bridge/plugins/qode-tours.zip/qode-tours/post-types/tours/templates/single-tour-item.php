<?php

get_header();

bridge_qode_get_title();

do_action('qode_before_main_content');

qode_tours_get_single_tour_item();

get_footer();

?>