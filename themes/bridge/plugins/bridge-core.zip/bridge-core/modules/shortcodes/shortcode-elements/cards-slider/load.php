<?php
include_once BRIDGE_CORE_SHORTCODES_PATH.'/cards-slider/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/cards-slider/cards-slider.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/cards-slider/cards-slider-item.php';