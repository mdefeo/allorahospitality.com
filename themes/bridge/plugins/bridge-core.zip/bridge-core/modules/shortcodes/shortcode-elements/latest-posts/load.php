<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/latest-posts/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/latest-posts/latest-posts.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/latest-posts/custom-styles/custom-styles.php';