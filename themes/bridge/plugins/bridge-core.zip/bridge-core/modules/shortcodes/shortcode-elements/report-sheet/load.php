<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/report-sheet/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/report-sheet/report-sheet.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/report-sheet/options-map/map.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/report-sheet/custom-styles/custom-styles.php';